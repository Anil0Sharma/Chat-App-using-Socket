const express = require("express");
const router = express.Router();
const {
  sendMessage,
  getMessages,
  getLatestMessages,
} = require("../controllers/messageController");

router.post("/", sendMessage);
router.get("/:senderId/:receiverId", getMessages);

//changes
router.get("/latest/:userId", getLatestMessages);

module.exports = router;
